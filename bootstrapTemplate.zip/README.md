# BootstrapTemplate
a simple bootstrap template
before this, you need install npm
1.download it
2.use terminal enter the project root file: cd BootstrapTemplate;
3.enter instruction:npm install
